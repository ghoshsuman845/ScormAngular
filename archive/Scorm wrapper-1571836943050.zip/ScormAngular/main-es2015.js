(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<router-outlet></router-outlet>\r\n<!--The content below is only a placeholder and can be replaced.-->\r\n<div style=\"text-align:center\">\r\n    <h1>\r\n      Welcome to {{ title }}!\r\n    </h1>\r\n  </div>\r\n  <article style=\"text-align:center\">\r\n    <p>\r\n      SCORM API version: {{apiVersion}}\r\n    </p>\r\n    <p>\r\n      Press the buttons to change your score. The score will be send to the LMS, if it is connected and SCORM_API is\r\n      found.\r\n    </p>\r\n  \r\n    <button (click)=\"changeScore(score-1)\">-</button>\r\n    {{score}}\r\n    <button (click)=\"changeScore(score+1)\">+</button>\r\n    <hr>\r\n    <div style=\"text-align:center\">\r\n      <button (click)=\"submitScore()\">Save</button>\r\n    </div>\r\n  </article>\r\n  \r\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/course-object/course-object.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/course-object/course-object.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"card\" id=\"page\" style=\" background-color: #212529;\"  >\n    <div class=\"card-body page-title\" >\n        What is Lorem Ipsum?\n    </div>\n    <div class=\"card-body page-inner\">\n        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n    </div>\n      \n</div>\n<div class=\"card\" >\n    <div class=\"card-body article-header\">\n        Where does it come from?\n    </div>\n    <div class=\"card-body article-body\">\n        Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\n\n        The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.       \n    </div>\n    <div class=\"card-body\" >\n        <div class=\"card\" id=\"block\" >\n            <div class=\"card-body block-title\">\n                Why do we use it?\n            </div>\n            <div class=\"card-body block-body\">\n                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n    \n            </div>\n        </div>\n    \n        <div class=\"card-body\" >\n          \n          <div class=\"card\" id=\"page\" style=\" background-color: #212529;\"  >\n            <div class=\"card-body graphics-title\" >\n                Where can I get some?\n            </div>\n            <div class=\"card-body graphics-inner\">\n                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.\n            </div>\n            <div class=\"card-body\" style=\"background-size:cover;\">\n                <img  src=\"assets/images/2.jpg\" alt=\"\" style=\"width: 90%;\n                height: 50vh;\">\n                \n            </div>\n      \n          </div>\n       </div>\n       <div class=\"card-body\" >\n          \n        <div class=\"card\" id=\"page\" style=\" background-color: #212529;\"  >\n          <div class=\"card-body graphics-title\" >\n              Take a Quiz\n          </div>\n          <div class=\"card-body graphics-inner\">\n            <!-- <p-radioButton name=\"groupname\" value=\"val1\" ></p-radioButton> <br> -->\n           \n\n            \n          </div>\n         \n    \n      </div>\n</div>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/course/course.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/course/course.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"card\" >\n    <div class=\"card-body\">\n      <h5 class=\"card-title\">Lorem Ipsum</h5>\n      <h6 class=\"card-subtitle mb-2 text-muted\">Development </h6>\n      <p class=\"card-text\">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\n\n            The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\n     \n    </div>\n</div>\n<div class=\"cont-2\"  >\n        <div class=\"row\"  >\n                <div class=\"col-6 col-sm-12 col-md-6 col-lg-6 col-xl-6\">\n                   \n                    <div class=\"card \"   >\n                        <div class=\"card-body\">\n                            <h5 class=\"card-title\" > What is Lorem Ipsum?</h5>\n                            <p class=\"card-text\" >\n                               Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n                              <br>\n                            It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n                           \n                             <div class=\"btnLink\"  routerLink='/course-object'>\n                                 <a  style=\" color: #fff;\">View</a>\n                             </div>\n                            <div class=\"progress\">\n                                <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 25%\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                            </div>\n                        </div>\n                                \n                    </div>\n                </div>\n                <div class=\"col-6 col-sm-12 col-md-6 col-lg-6 col-xl-6\">\n                   \n                        <div class=\"card \"   >\n                            <div class=\"card-body\">\n                                <h5 class=\"card-title\" > What is Lorem Ipsum?</h5>\n                                <p class=\"card-text\" >\n                                   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n                                  <br>\n                                  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n\n                                </p>\n                                 <div class=\"btnLink\"  routerLink='/course-object'>\n                                     <a  style=\" color: #fff;\">View</a>\n                                 </div>\n                                <div class=\"progress\">\n                                    <div class=\"progress-bar bg-primary\" role=\"progressbar\" style=\"width: 25%\" aria-valuenow=\"25\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>\n                                </div>\n                            </div>\n                                    \n                        </div>\n                    </div>\n              \n                       \n              </div>\n</div> \n");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _course_course_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course/course.component */ "./src/app/course/course.component.ts");
/* harmony import */ var _course_object_course_object_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./course-object/course-object.component */ "./src/app/course-object/course-object.component.ts");





const routes = [
    { path: '', redirectTo: '/course', pathMatch: 'full' },
    { path: 'course',
        component: _course_course_component__WEBPACK_IMPORTED_MODULE_3__["CourseComponent"],
    },
    { path: 'course-object',
        component: _course_object_course_object_component__WEBPACK_IMPORTED_MODULE_4__["CourseObjectComponent"],
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/scorm.service */ "./src/app/services/scorm.service.ts");



let AppComponent = class AppComponent {
    constructor(scormService) {
        this.scormService = scormService;
        this.title = 'scormCourseAngular';
        this.score = 0;
        this.maxScore = 100;
        this.minScore = 0;
        this.apiVersion = 'not found';
        this.apiVersion = scormService.apiVersion;
        this.score = scormService.score;
    }
    changeScore(score) {
        if (score >= this.minScore && score <= this.maxScore) {
            this.score = score;
            this.scormService.score = this.score;
        }
        else {
            this.score = score < this.minScore ? this.minScore : this.maxScore;
        }
    }
    submitScore() {
        this.scormService.commit(); // Finally saves data to LMS
        this.scormService.terminate();
        window.close();
    }
};
AppComponent.ctorParameters = () => [
    { type: src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_2__["ScormService"] }
];
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var ngx_scorm_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-scorm-wrapper */ "./node_modules/ngx-scorm-wrapper/dist/index.js");
/* harmony import */ var src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/scorm.service */ "./src/app/services/scorm.service.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _course_course_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./course/course.component */ "./src/app/course/course.component.ts");
/* harmony import */ var _course_object_course_object_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./course-object/course-object.component */ "./src/app/course-object/course-object.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");









// import {RadioButtonModule} from 'primeng/radiobutton';

let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
            _course_course_component__WEBPACK_IMPORTED_MODULE_7__["CourseComponent"],
            _course_object_course_object_component__WEBPACK_IMPORTED_MODULE_8__["CourseObjectComponent"],
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            ngx_scorm_wrapper__WEBPACK_IMPORTED_MODULE_3__["ScormWrapperModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__["BrowserAnimationsModule"],
            // RadioButtonModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"]
        ],
        providers: [
            src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_4__["ScormService"]
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/course-object/course-object.component.scss":
/*!************************************************************!*\
  !*** ./src/app/course-object/course-object.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card {\n  width: 94% !important;\n  margin-left: 4% !important;\n  border-radius: 0px;\n  align-items: center;\n}\n\n.page-title {\n  margin-bottom: 0.75rem;\n  text-align: center;\n  color: #fff;\n  text-transform: uppercase;\n  font-family: lato;\n  font-weight: 700;\n  font-size: 37px;\n}\n\n.page-inner {\n  font-family: lato;\n  color: #fff;\n  font-size: 20px;\n  margin: 1px;\n  padding: 2px 18px;\n}\n\n.article-header {\n  color: black;\n  font-family: lato;\n  font-size: 50px;\n}\n\n.article-body {\n  color: black;\n  font-family: lato;\n  font-size: 20px;\n  padding: 2px 24px;\n}\n\n.block-title {\n  color: #000;\n  font-family: lato;\n  font-size: 50px;\n}\n\n.block-body {\n  color: #000;\n  font-family: lato;\n  font-size: 20px;\n  padding: 2px 24px;\n}\n\n.graphics-title {\n  color: #fff;\n  font-family: lato;\n  font-size: 50px;\n}\n\n.graphics-inner {\n  color: #fff;\n  font-family: lato;\n  font-size: 20px;\n  padding: 2px 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY291cnNlLW9iamVjdC9EOlxcU2Nvcm1Bbmd1bGFyL3NyY1xcYXBwXFxjb3Vyc2Utb2JqZWN0XFxjb3Vyc2Utb2JqZWN0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb3Vyc2Utb2JqZWN0L2NvdXJzZS1vYmplY3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxxQkFBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFFQSxtQkFBQTtBQ0RKOztBREdBO0VBQ0ksc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FDQUo7O0FERUE7RUFFSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FDQUo7O0FERUE7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURDQTtFQUVJLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURDSTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0VKOztBREFJO0VBRUksV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQ0VSOztBREFRO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDR1IiLCJmaWxlIjoic3JjL2FwcC9jb3Vyc2Utb2JqZWN0L2NvdXJzZS1vYmplY3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZHtcclxuICAgIFxyXG4gICAgd2lkdGg6IDk0JSFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNCUhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogIzIxMjUyOTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLnBhZ2UtdGl0bGV7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAuNzVyZW07XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBmb250LWZhbWlseTogbGF0bztcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBmb250LXNpemU6IDM3cHg7XHJcbiAgICBcclxufVxyXG4ucGFnZS1pbm5lcntcclxuICAgIGZvbnQtZmFtaWx5OiBsYXRvO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBtYXJnaW46IDFweDtcclxuICAgIHBhZGRpbmc6IDJweCAxOHB4O1xyXG59XHJcbi5hcnRpY2xlLWhlYWRlcntcclxuICAgIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGZvbnQtZmFtaWx5OiBsYXRvO1xyXG4gICAgZm9udC1zaXplOiA1MHB4O1xyXG59XHJcbi5hcnRpY2xlLWJvZHl7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBmb250LWZhbWlseTogbGF0bztcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHBhZGRpbmc6IDJweCAyNHB4O1xyXG59XHJcbi5ibG9jay10aXRsZXtcclxuICAgIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICBmb250LXNpemU6IDUwcHg7XHJcbiAgICB9XHJcbiAgICAuYmxvY2stYm9keXtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBwYWRkaW5nOiAycHggMjRweDtcclxuICAgIH1cclxuICAgIC5ncmFwaGljcy10aXRsZXtcclxuICAgICAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICAgICAgZm9udC1zaXplOiA1MHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZ3JhcGhpY3MtaW5uZXJ7XHJcbiAgICAgICAgY29sb3I6I2ZmZjtcclxuICAgICAgICBmb250LWZhbWlseTogbGF0bztcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgcGFkZGluZzogMnB4IDI0cHg7XHJcbiAgICAgICAgfSIsIi5jYXJkIHtcbiAgd2lkdGg6IDk0JSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogNCUgIWltcG9ydGFudDtcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4ucGFnZS10aXRsZSB7XG4gIG1hcmdpbi1ib3R0b206IDAuNzVyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtZmFtaWx5OiBsYXRvO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDM3cHg7XG59XG5cbi5wYWdlLWlubmVyIHtcbiAgZm9udC1mYW1pbHk6IGxhdG87XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbjogMXB4O1xuICBwYWRkaW5nOiAycHggMThweDtcbn1cblxuLmFydGljbGUtaGVhZGVyIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LWZhbWlseTogbGF0bztcbiAgZm9udC1zaXplOiA1MHB4O1xufVxuXG4uYXJ0aWNsZS1ib2R5IHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LWZhbWlseTogbGF0bztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nOiAycHggMjRweDtcbn1cblxuLmJsb2NrLXRpdGxlIHtcbiAgY29sb3I6ICMwMDA7XG4gIGZvbnQtZmFtaWx5OiBsYXRvO1xuICBmb250LXNpemU6IDUwcHg7XG59XG5cbi5ibG9jay1ib2R5IHtcbiAgY29sb3I6ICMwMDA7XG4gIGZvbnQtZmFtaWx5OiBsYXRvO1xuICBmb250LXNpemU6IDIwcHg7XG4gIHBhZGRpbmc6IDJweCAyNHB4O1xufVxuXG4uZ3JhcGhpY3MtdGl0bGUge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1mYW1pbHk6IGxhdG87XG4gIGZvbnQtc2l6ZTogNTBweDtcbn1cblxuLmdyYXBoaWNzLWlubmVyIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtZmFtaWx5OiBsYXRvO1xuICBmb250LXNpemU6IDIwcHg7XG4gIHBhZGRpbmc6IDJweCAyNHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/course-object/course-object.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/course-object/course-object.component.ts ***!
  \**********************************************************/
/*! exports provided: CourseObjectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseObjectComponent", function() { return CourseObjectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CourseObjectComponent = class CourseObjectComponent {
    constructor() { }
    ngOnInit() {
    }
};
CourseObjectComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-course-object',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./course-object.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/course-object/course-object.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./course-object.component.scss */ "./src/app/course-object/course-object.component.scss")).default]
    })
], CourseObjectComponent);



/***/ }),

/***/ "./src/app/course/course.component.scss":
/*!**********************************************!*\
  !*** ./src/app/course/course.component.scss ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card {\n  width: 107%;\n  border-radius: 0px;\n  background-color: #212529;\n  margin-left: -3%;\n}\n.card .card-title {\n  margin-bottom: 0.75rem;\n  text-align: center;\n  color: #fff;\n  text-transform: uppercase;\n  font-family: lato;\n  font-weight: 700;\n  font-size: 37px;\n  padding: 21px 5px;\n}\n.card .text-muted {\n  text-align: center;\n  font-family: lato;\n  margin: -39px auto;\n}\n.card .card-text {\n  font-family: lato;\n  color: #fff;\n  font-size: 20px;\n  margin: 1px;\n  padding: 12px 51px;\n}\n.cont-2 .card {\n  border-radius: 0px;\n  margin-bottom: 15px;\n  width: 94%;\n  box-shadow: 5px 5px 5px #dddbdb;\n  background-color: white;\n  margin-top: -24px;\n  margin-left: 16px;\n}\n.cont-2 .card .card-body {\n  margin-top: -17px;\n  margin-left: -8px;\n}\n.cont-2 .card .card-title {\n  margin-bottom: 0.75rem;\n  font-family: lato;\n  font-weight: 700;\n  color: #212529;\n  font-size: 37px;\n  padding: 21px 5px;\n}\n.cont-2 .card .card-text {\n  font-family: lato;\n  font-size: 20px;\n  margin: 1px;\n  padding: 12px 6px;\n  color: #B5B5B5;\n}\n.cont-2 .card .btnLink {\n  background: #373d47;\n  color: #fff;\n  border-radius: 20px;\n  width: 24%;\n  height: 33px;\n  padding: 3px;\n  text-align: center;\n  margin: 22px 8px;\n  cursor: pointer;\n}\n.cont-2 .card .progress {\n  display: flex;\n  height: 7px;\n  width: 103%;\n  margin-top: 18px;\n  margin-bottom: -8px;\n  overflow: hidden;\n  font-size: 0.75rem;\n  background-color: #e9ecef;\n  border-radius: 0.25rem;\n}\n.cont-2 .card .progress .bg-primary {\n  background-color: #6c63ff !important;\n}\n.course-object {\n  margin-top: 2%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY291cnNlL0Q6XFxTY29ybUFuZ3VsYXIvc3JjXFxhcHBcXGNvdXJzZVxcY291cnNlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb3Vyc2UvY291cnNlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQWdCSTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7QUNmUjtBRGdCSTtFQUNJLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDZFI7QURnQkk7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNkUjtBRGlCSTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNmUjtBRDBCSTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsK0JBQUE7RUFDQSx1QkFBQTtFQUVBLGlCQUFBO0VBQ0EsaUJBQUE7QUN4QlI7QUR5QlE7RUFDSSxpQkFBQTtFQUNKLGlCQUFBO0FDdkJSO0FEeUJRO0VBQ0ksc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ3ZCWjtBRDBCUTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUN4QlI7QUQwQlE7RUFDSSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDeEJaO0FEMEJRO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0FDeEJaO0FEeUJZO0VBQ0ksb0NBQUE7QUN2QmhCO0FENkJBO0VBQ0ksY0FBQTtBQzFCSiIsImZpbGUiOiJzcmMvYXBwL2NvdXJzZS9jb3Vyc2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyAuY29udGFpbmVye1xyXG4vLyAgICAgLmNhcmQtaW1ne1xyXG4vLyAgICAgICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuLy8gICAgIH1cclxuLy8gICAgIC5pbWctMXtcclxuLy8gICAgICAgIHdpZHRoOiAxMTAlO1xyXG4gICAgICBcclxuLy8gICAgIH1cclxuLy8gICAgIC5pbWctMntcclxuLy8gICAgICAgICB3aWR0aDogMTY2JTtcclxuLy8gICAgICAgICBtYXJnaW4tbGVmdDogMzAlO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgLmltZy0ze1xyXG4vLyAgICAgICAgIGhlaWdodDogMjAycHg7XHJcbi8vICAgICAgbWFyZ2luLXRvcDogOCU7XHJcbi8vICAgICB9XHJcbiAgICAuY2FyZHtcclxuICAgICAgICB3aWR0aDogMTA3JTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzIxMjUyOTtcclxuICAgICAgICBtYXJnaW4tbGVmdDogLTMlO1xyXG4gICAgLmNhcmQtdGl0bGUge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDAuNzVyZW07XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICBmb250LXNpemU6IDM3cHg7XHJcbiAgICAgICAgcGFkZGluZzogMjFweCA1cHg7XHJcbiAgICB9XHJcbiAgICAudGV4dC1tdXRlZHtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICAgICAgbWFyZ2luOiAtMzlweCBhdXRvO1xyXG5cclxuICAgIH1cclxuICAgIC5jYXJkLXRleHR7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IGxhdG87XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgIG1hcmdpbjogMXB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDEycHggNTFweDtcclxuXHJcblxyXG4gICAgfVxyXG4gICBcclxuXHJcbiAgICB9XHJcbiAgIFxyXG4gXHJcbi8vIH1cclxuLmNvbnQtMntcclxuICAgIC5jYXJke1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDBweDsgXHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgICAgICB3aWR0aDogOTQlO1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDVweCA1cHggNXB4ICNkZGRiZGI7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICAgICBcclxuICAgICAgICBtYXJnaW4tdG9wOiAtMjRweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcclxuICAgICAgICAuY2FyZC1ib2R5e1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAtMTdweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogLThweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNhcmQtdGl0bGUge1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjc1cmVtO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogbGF0bztcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICAgICAgY29sb3I6ICMyMTI1Mjk7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzdweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMjFweCA1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgXHJcbiAgICAgICAgLmNhcmQtdGV4dHtcclxuICAgICAgICBmb250LWZhbWlseTogbGF0bztcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAxcHg7XHJcbiAgICAgICAgcGFkZGluZzogMTJweCA2cHg7XHJcbiAgICAgICAgY29sb3I6ICNCNUI1QjU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5idG5MaW5rIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogIzM3M2Q0NztcclxuICAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyNCU7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzNweDtcclxuICAgICAgICAgICAgcGFkZGluZzogM3B4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMjJweCA4cHg7XHJcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnByb2dyZXNzIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgaGVpZ2h0OiA3cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDMlO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxOHB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAtOHB4O1xyXG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IC43NXJlbTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZWNlZjtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xyXG4gICAgICAgICAgICAuYmctcHJpbWFyeSB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmM2M2ZmIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4uY291cnNlLW9iamVjdHtcclxuICAgIG1hcmdpbi10b3A6IDIlO1xyXG59XHJcbiIsIi5jYXJkIHtcbiAgd2lkdGg6IDEwNyU7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzIxMjUyOTtcbiAgbWFyZ2luLWxlZnQ6IC0zJTtcbn1cbi5jYXJkIC5jYXJkLXRpdGxlIHtcbiAgbWFyZ2luLWJvdHRvbTogMC43NXJlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1mYW1pbHk6IGxhdG87XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtc2l6ZTogMzdweDtcbiAgcGFkZGluZzogMjFweCA1cHg7XG59XG4uY2FyZCAudGV4dC1tdXRlZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1mYW1pbHk6IGxhdG87XG4gIG1hcmdpbjogLTM5cHggYXV0bztcbn1cbi5jYXJkIC5jYXJkLXRleHQge1xuICBmb250LWZhbWlseTogbGF0bztcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbWFyZ2luOiAxcHg7XG4gIHBhZGRpbmc6IDEycHggNTFweDtcbn1cblxuLmNvbnQtMiAuY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgd2lkdGg6IDk0JTtcbiAgYm94LXNoYWRvdzogNXB4IDVweCA1cHggI2RkZGJkYjtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIG1hcmdpbi10b3A6IC0yNHB4O1xuICBtYXJnaW4tbGVmdDogMTZweDtcbn1cbi5jb250LTIgLmNhcmQgLmNhcmQtYm9keSB7XG4gIG1hcmdpbi10b3A6IC0xN3B4O1xuICBtYXJnaW4tbGVmdDogLThweDtcbn1cbi5jb250LTIgLmNhcmQgLmNhcmQtdGl0bGUge1xuICBtYXJnaW4tYm90dG9tOiAwLjc1cmVtO1xuICBmb250LWZhbWlseTogbGF0bztcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgY29sb3I6ICMyMTI1Mjk7XG4gIGZvbnQtc2l6ZTogMzdweDtcbiAgcGFkZGluZzogMjFweCA1cHg7XG59XG4uY29udC0yIC5jYXJkIC5jYXJkLXRleHQge1xuICBmb250LWZhbWlseTogbGF0bztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW46IDFweDtcbiAgcGFkZGluZzogMTJweCA2cHg7XG4gIGNvbG9yOiAjQjVCNUI1O1xufVxuLmNvbnQtMiAuY2FyZCAuYnRuTGluayB7XG4gIGJhY2tncm91bmQ6ICMzNzNkNDc7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICB3aWR0aDogMjQlO1xuICBoZWlnaHQ6IDMzcHg7XG4gIHBhZGRpbmc6IDNweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDIycHggOHB4O1xuICBjdXJzb3I6IHBvaW50ZXI7XG59XG4uY29udC0yIC5jYXJkIC5wcm9ncmVzcyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGhlaWdodDogN3B4O1xuICB3aWR0aDogMTAzJTtcbiAgbWFyZ2luLXRvcDogMThweDtcbiAgbWFyZ2luLWJvdHRvbTogLThweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgZm9udC1zaXplOiAwLjc1cmVtO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTllY2VmO1xuICBib3JkZXItcmFkaXVzOiAwLjI1cmVtO1xufVxuLmNvbnQtMiAuY2FyZCAucHJvZ3Jlc3MgLmJnLXByaW1hcnkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmM2M2ZmICFpbXBvcnRhbnQ7XG59XG5cbi5jb3Vyc2Utb2JqZWN0IHtcbiAgbWFyZ2luLXRvcDogMiU7XG59Il19 */");

/***/ }),

/***/ "./src/app/course/course.component.ts":
/*!********************************************!*\
  !*** ./src/app/course/course.component.ts ***!
  \********************************************/
/*! exports provided: CourseComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseComponent", function() { return CourseComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/scorm.service */ "./src/app/services/scorm.service.ts");



let CourseComponent = class CourseComponent {
    constructor(scormService) {
        this.scormService = scormService;
        this.score = 0;
        this.maxScore = 100;
        this.minScore = 0;
        this.apiVersion = 'not found';
        this.apiVersion = scormService.apiVersion;
        this.score = scormService.score;
    }
    changeScore(score) {
        if (score >= this.minScore && score <= this.maxScore) {
            this.score = score;
            this.scormService.score = this.score;
        }
        else {
            this.score = score < this.minScore ? this.minScore : this.maxScore;
        }
    }
    submitScore() {
        this.scormService.commit(); // Finally saves data to LMS
        this.scormService.terminate();
        window.close();
    }
    ngOnInit() {
    }
};
CourseComponent.ctorParameters = () => [
    { type: src_app_services_scorm_service__WEBPACK_IMPORTED_MODULE_2__["ScormService"] }
];
CourseComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-course',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./course.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/course/course.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./course.component.scss */ "./src/app/course/course.component.scss")).default]
    })
], CourseComponent);



/***/ }),

/***/ "./src/app/services/scorm.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/scorm.service.ts ***!
  \*******************************************/
/*! exports provided: ScormService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScormService", function() { return ScormService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var ngx_scorm_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-scorm-wrapper */ "./node_modules/ngx-scorm-wrapper/dist/index.js");
/* harmony import */ var src_app_timeConverter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/timeConverter */ "./src/app/timeConverter.ts");




let ScormService = class ScormService {
    constructor(scormWrapper) {
        this.scormWrapper = scormWrapper;
        try {
            this.scormWrapper.doLMSInitialize(); // Try to find SCORM_API and initialize it
        }
        catch (err) {
            console.log('Cannot find LMS API');
        }
        if (!scormWrapper.LMSIsInitialized) {
            console.warn('LMS is not connected');
            return;
        }
        else {
            console.warn('LMS is connected');
            this.startTime = new Date().getTime();
            this.scormWrapper.doLMSSetValue('cmi.score.max', '100');
            this.scormWrapper.doLMSSetValue('cmi.location', '0:0'); // assume that the format is <chapter>:<page>
            this.scormWrapper.doLMSSetValue('cmi.session_time', this.sessionTime);
            this.scormWrapper.doLMSSetValue('cmi.completion_status', 'incomplete');
            this.commit();
        }
    }
    get apiVersion() {
        return this.scormWrapper.APIVersion;
    }
    get sessionTime() {
        if (this.startTime) {
            const currentTime = new Date().getTime();
            return Object(src_app_timeConverter__WEBPACK_IMPORTED_MODULE_3__["default"])((currentTime - this.startTime) / 1000);
        }
        return '00:00:00.0';
    }
    get score() {
        if (this.scormWrapper.LMSIsInitialized) {
            const scaledScore = +(this.scormWrapper.doLMSGetValue('cmi.score.scaled') || 0);
            const rawScore = +(this.scormWrapper.doLMSGetValue('cmi.score.raw') || 0);
            return scaledScore * 100 || rawScore;
        }
        console.warn('LMS is not connected');
        return 0;
    }
    set score(score) {
        if (this.scormWrapper.LMSIsInitialized) {
            this.scormWrapper.doLMSSetValue('cmi.score.scaled', '' + score / 100);
            return;
        }
        console.warn('LMS is not connected');
    }
    commit() {
        this.scormWrapper.doLMSCommit();
    }
    terminate() {
        this.scormWrapper.doLMSFinish();
    }
    getSuspendData() {
        if (!this.scormWrapper.LMSIsInitialized) {
            console.warn('LMS is not connected');
            return null;
        }
        const suspendData = this.scormWrapper.doLMSGetValue('cmi.suspend_data');
        if (suspendData) {
            return JSON.parse(suspendData);
        }
        return null;
    }
    sendData(data) {
        if (!this.scormWrapper.LMSIsInitialized) {
            console.warn('LMS is not connected');
            return null;
        }
        const { score, location, completionStatus, suspendData } = data;
        this.scormWrapper.doLMSSetValue('cmi.score.max', '100');
        this.scormWrapper.doLMSSetValue('cmi.location', location); // assume that the format is <chapter>:<page>
        this.scormWrapper.doLMSSetValue('cmi.session_time', this.sessionTime);
        this.scormWrapper.doLMSSetValue('cmi.completion_status', completionStatus);
        this.scormWrapper.doLMSSetValue('cmi.score.scaled', score / 100 + '');
        this.scormWrapper.doLMSSetValue('cmi.core.lesson_location', location);
        this.scormWrapper.doLMSSetValue('cmi.suspend_data', JSON.stringify(suspendData));
        this.commit();
    }
    getData() {
        if (!this.scormWrapper.LMSIsInitialized) {
            console.warn('LMS is not connected');
            return null;
        }
        const suspendData = this.scormWrapper.doLMSGetValue('cmi.suspend_data');
        if (suspendData) {
            return JSON.parse(suspendData);
        }
        return null;
    }
};
ScormService.ctorParameters = () => [
    { type: ngx_scorm_wrapper__WEBPACK_IMPORTED_MODULE_2__["ScormWrapperService"] }
];
ScormService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ScormService);



/***/ }),

/***/ "./src/app/timeConverter.ts":
/*!**********************************!*\
  !*** ./src/app/timeConverter.ts ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

/*******************************************************************************
 ** this function will convert seconds into hours, minutes, and seconds in
 ** CMITimespan type format - HHHH:MM:SS.SS (Hours has a max of 4 digits &
 ** Min of 2 digits
 *******************************************************************************/
const convertTotalSeconds = (totalSeconds) => {
    let sec = (totalSeconds % 60);
    totalSeconds -= sec;
    const tmp = (totalSeconds % 3600); // of seconds in the total # of minutes
    totalSeconds -= tmp; // of seconds in the total # of hours
    // convert seconds to conform to CMITimespan type (e.g. SS.00)
    sec = Math.round(sec * 100) / 100;
    let strSec = sec.toString();
    let strWholeSec = strSec;
    let strFractionSec = '';
    if (strSec.indexOf('.') !== -1) {
        strWholeSec = strSec.substring(0, strSec.indexOf('.'));
        strFractionSec = strSec.substring(strSec.indexOf('.') + 1, strSec.length);
    }
    if (strWholeSec.length < 2) {
        strWholeSec = '0' + strWholeSec;
    }
    strSec = strWholeSec;
    if (strFractionSec.length) {
        strSec = strSec + '.' + strFractionSec;
    }
    let hour;
    let min;
    if ((totalSeconds % 3600) !== 0) {
        hour = 0;
    }
    else {
        hour = (totalSeconds / 3600);
    }
    if ((tmp % 60) !== 0) {
        min = 0;
    }
    else {
        min = (tmp / 60);
    }
    const strHour = (hour.toString().length < 2) ? `0${hour}` : hour;
    const strMin = (min.toString().length < 2) ? `0${min}` : min;
    return `${strHour}:${strMin}:${strSec}`;
};
/* harmony default export */ __webpack_exports__["default"] = (convertTotalSeconds);


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\ScormAngular\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map